# 2021-NCKU-IDS-HW5
<pre>
Please name the text file as the following format : name_ID.txt
(e.g. 王小明_H12345678.txt)

Otherwise, about 5% of the score of this homework will be deducted.
</pre>
